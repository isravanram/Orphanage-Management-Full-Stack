-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 28, 2020 at 05:17 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `yourcare`
--

-- --------------------------------------------------------

--
-- Table structure for table `orphans`
--

CREATE TABLE `orphans` (
  `ID` int(11) NOT NULL,
  `Name` varchar(80) NOT NULL,
  `Age` int(2) NOT NULL,
  `Gender` varchar(40) NOT NULL,
  `Education` varchar(90) NOT NULL,
  `Height` varchar(20) NOT NULL,
  `Weight` varchar(20) NOT NULL,
  `Physical_description` varchar(150) NOT NULL,
  `Health_status` varchar(150) NOT NULL,
  `Photo` varchar(20) NOT NULL,
  `Hobbies` varchar(180) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orphans`
--

INSERT INTO `orphans` (`ID`, `Name`, `Age`, `Gender`, `Education`, `Height`, `Weight`, `Physical_description`, `Health_status`, `Photo`, `Hobbies`) VALUES
(1, 'Raju', 12, 'Male', 'Class 4', '123cm', '40kg', 'Short,brown hair', 'No health issues.', 'raju.jpg', 'Playing cricket,basketball.'),
(3, 'Durga', 12, 'Male', 'class 4', '124', '45', 'Brown eyes,black hair', 'No health issues', 'durga2.jpg', 'Football, chess , drawing.'),
(4, 'Diya', 13, 'Female', 'Class 9', '133cm', '50kg', 'Slim, brown hair', 'No health issues', 'diya.jpg', 'Painting, Swimming,Dance'),
(5, 'Aliya', 14, 'Female', 'Class 9', '122cm', '40kg', 'Brown eyes', 'No health issues.', '', 'Chess,Volleyball,Painting');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orphans`
--
ALTER TABLE `orphans`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orphans`
--
ALTER TABLE `orphans`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
